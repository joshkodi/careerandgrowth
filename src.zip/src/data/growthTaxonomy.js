// src/data/growthTaxonomy.js

export const GROWTH_MODEL_VERSION = '0.3.0'

export const signals = {
  curiosity: { id: 'curiosity', label: 'Curiosity', description: 'Shows interest in understanding, discovering, or exploring.' },
  enjoyment: { id: 'enjoyment', label: 'Enjoyment', description: 'Shows positive engagement or enjoyment in an activity.' },
  challenge_seeking: { id: 'challenge_seeking', label: 'Challenge Seeking', description: 'Shows interest in tackling difficult or unfamiliar challenges.' },
  problem_solving: { id: 'problem_solving', label: 'Problem Solving', description: 'Tries to figure out problems, obstacles, or unexpected situations.' },
  pattern_recognition: { id: 'pattern_recognition', label: 'Pattern Recognition', description: 'Notices relationships, similarities, sequences, or patterns.' },
  creative_thinking: { id: 'creative_thinking', label: 'Creative Thinking', description: 'Generates original ideas, alternatives, stories, or possibilities.' },
  analytical_thinking: { id: 'analytical_thinking', label: 'Analytical Thinking', description: 'Breaks information into parts and reasons through it logically.' },
  hands_on: { id: 'hands_on', label: 'Hands-On', description: 'Prefers learning by doing, building, manipulating, or making.' },
  experimenting: { id: 'experimenting', label: 'Experimenting', description: 'Tests ideas and learns by trying different approaches.' },
  creating: { id: 'creating', label: 'Creating', description: 'Enjoys producing, designing, building, or inventing something.' },
  helping: { id: 'helping', label: 'Helping', description: 'Shows motivation to assist or improve outcomes for others.' },
  communicating: { id: 'communicating', label: 'Communicating', description: 'Enjoys explaining, presenting, describing, or sharing ideas.' },
  leading: { id: 'leading', label: 'Leading', description: 'Shows initiative in organizing, guiding, or directing.' },
  collaborating: { id: 'collaborating', label: 'Collaborating', description: 'Shows preference for working with or learning alongside others.' },
  persistence: { id: 'persistence', label: 'Persistence', description: 'Continues working despite difficulty, uncertainty, or setbacks.' },
}

export const traits = {
  curious_investigator: {
    id: 'curious_investigator', label: 'Curious Investigator', emoji: '🔍',
    description: 'Enjoys asking why, exploring, and discovering how things work.',
    signalWeights: { curiosity: 1.0, experimenting: 0.6, analytical_thinking: 0.4, pattern_recognition: 0.3 },
  },
  problem_solver: {
    id: 'problem_solver', label: 'Problem Solver', emoji: '🧩',
    description: 'Enjoys figuring out problems and finding workable solutions.',
    signalWeights: { problem_solving: 1.0, analytical_thinking: 0.6, persistence: 0.4, experimenting: 0.3 },
  },
  builder: {
    id: 'builder', label: 'Builder', emoji: '🛠️',
    description: 'Enjoys making, constructing, assembling, and improving things.',
    signalWeights: { hands_on: 1.0, creating: 0.8, problem_solving: 0.5, persistence: 0.3 },
  },
  creator: {
    id: 'creator', label: 'Creator', emoji: '🎨',
    description: 'Enjoys creating original things and expressing ideas.',
    signalWeights: { creating: 1.0, creative_thinking: 0.9, curiosity: 0.3 },
  },
  imaginative_thinker: {
    id: 'imaginative_thinker', label: 'Imaginative Thinker', emoji: '💡',
    description: 'Enjoys imagining possibilities and generating new ideas.',
    signalWeights: { creative_thinking: 1.0, creating: 0.5, curiosity: 0.4 },
  },
  helper: {
    id: 'helper', label: 'Helper', emoji: '🤝',
    description: 'Shows motivation to help people and improve their experiences.',
    signalWeights: { helping: 1.0, collaborating: 0.5, communicating: 0.3 },
  },
  communicator: {
    id: 'communicator', label: 'Communicator', emoji: '🗣️',
    description: 'Enjoys explaining, sharing, presenting, and discussing ideas.',
    signalWeights: { communicating: 1.0, collaborating: 0.4, creative_thinking: 0.2 },
  },
  leader: {
    id: 'leader', label: 'Leader', emoji: '🧭',
    description: 'Shows initiative and enjoys organizing or guiding others.',
    signalWeights: { leading: 1.0, communicating: 0.5, collaborating: 0.3, persistence: 0.2 },
  },
  experimenter: {
    id: 'experimenter', label: 'Experimenter', emoji: '🧪',
    description: 'Enjoys learning through testing, trying, and observing results.',
    signalWeights: { experimenting: 1.0, curiosity: 0.6, problem_solving: 0.4, challenge_seeking: 0.3 },
  },
  pattern_finder: {
    id: 'pattern_finder', label: 'Pattern Finder', emoji: '📊',
    description: 'Enjoys finding relationships, structures, and recurring patterns.',
    signalWeights: { pattern_recognition: 1.0, analytical_thinking: 0.7, curiosity: 0.3 },
  },
  achiever: {
    id: 'achiever', label: 'Achiever', emoji: '🏆',
    description: 'Enjoys challenge, progress, mastery, and reaching goals.',
    signalWeights: { challenge_seeking: 1.0, persistence: 0.7, enjoyment: 0.3 },
  },
  persistent_learner: {
    id: 'persistent_learner', label: 'Persistent Learner', emoji: '🌱',
    description: 'Continues learning and trying even when something is difficult.',
    signalWeights: { persistence: 1.0, challenge_seeking: 0.4, experimenting: 0.3, problem_solving: 0.3 },
  },
}

export const domains = {
  technology_robotics: { id: 'technology_robotics', label: 'Technology & Robotics', emoji: '🤖', description: 'Technology, computing, robotics, automation, and intelligent systems.' },
  health_human_body: { id: 'health_human_body', label: 'Health & Human Body', emoji: '🧬', description: 'Human biology, health, medicine, and how the body works.' },
  science_discovery: { id: 'science_discovery', label: 'Science & Discovery', emoji: '🔬', description: 'Scientific investigation, observation, experimentation, and discovery.' },
  creative_arts_storytelling: { id: 'creative_arts_storytelling', label: 'Creative Arts & Storytelling', emoji: '🎨', description: 'Stories, visual creativity, imagination, media, and artistic expression.' },
  engineering_making: { id: 'engineering_making', label: 'Engineering & Making', emoji: '🏗️', description: 'Designing, building, inventing, constructing, and improving things.' },
  nature_environment: { id: 'nature_environment', label: 'Nature & Environment', emoji: '🌎', description: 'Animals, ecosystems, earth science, sustainability, and the environment.' },
  business_entrepreneurship: { id: 'business_entrepreneurship', label: 'Business & Entrepreneurship', emoji: '💼', description: 'Ideas, products, customers, leadership, business, and entrepreneurship.' },
  people_society: { id: 'people_society', label: 'People & Society', emoji: '🤝', description: 'People, communities, communication, leadership, and social challenges.' },
}

export const pathways = {
  engineering_intelligent_systems: {
    id: 'engineering_intelligent_systems', label: 'Engineering & Intelligent Systems', emoji: '⚙️',
    description: 'Building, understanding, and improving machines, technology, and intelligent systems.',
    traitWeights: { builder: 0.3, problem_solver: 0.3, experimenter: 0.15, persistent_learner: 0.1 },
    domainWeights: { technology_robotics: 0.1, engineering_making: 0.05 },
  },
  health_human_sciences: {
    id: 'health_human_sciences', label: 'Health & Human Sciences', emoji: '🧬',
    description: 'Understanding people, health, biology, and improving human well-being.',
    traitWeights: { curious_investigator: 0.25, helper: 0.25, problem_solver: 0.15, persistent_learner: 0.1 },
    domainWeights: { health_human_body: 0.2, science_discovery: 0.05 },
  },
  science_exploration: {
    id: 'science_exploration', label: 'Science & Exploration', emoji: '🔭',
    description: 'Investigating the world through curiosity, evidence, experimentation, and discovery.',
    traitWeights: { curious_investigator: 0.3, experimenter: 0.25, pattern_finder: 0.15, problem_solver: 0.1 },
    domainWeights: { science_discovery: 0.2 },
  },
  creative_design_expression: {
    id: 'creative_design_expression', label: 'Creative Design & Expression', emoji: '🎨',
    description: 'Creating ideas, stories, designs, experiences, and new forms of expression.',
    traitWeights: { creator: 0.3, imaginative_thinker: 0.25, communicator: 0.15 },
    domainWeights: { creative_arts_storytelling: 0.2, engineering_making: 0.1 },
  },
  environment_living_systems: {
    id: 'environment_living_systems', label: 'Environment & Living Systems', emoji: '🌎',
    description: 'Exploring living systems, nature, animals, ecosystems, and environmental challenges.',
    traitWeights: { curious_investigator: 0.25, helper: 0.2, experimenter: 0.15, problem_solver: 0.1 },
    domainWeights: { nature_environment: 0.25, science_discovery: 0.05 },
  },
  innovation_entrepreneurship: {
    id: 'innovation_entrepreneurship', label: 'Innovation & Entrepreneurship', emoji: '🚀',
    description: 'Creating ideas, solving needs, leading initiatives, and turning ideas into reality.',
    traitWeights: { creator: 0.2, leader: 0.2, problem_solver: 0.15, communicator: 0.1, achiever: 0.1 },
    domainWeights: { business_entrepreneurship: 0.2, engineering_making: 0.05 },
  },
  people_leadership_society: {
    id: 'people_leadership_society', label: 'People, Leadership & Society', emoji: '🤝',
    description: 'Helping, communicating with, organizing, and improving outcomes for people and communities.',
    traitWeights: { helper: 0.3, communicator: 0.25, leader: 0.25 },
    domainWeights: { people_society: 0.2 },
  },
}

export const careerFamilies = {
  robotics_autonomous_systems: { id: 'robotics_autonomous_systems', label: 'Robotics & Autonomous Systems', pathwayIds: ['engineering_intelligent_systems'], examples: ['Robotics Engineer', 'Autonomous Systems Engineer', 'Mechatronics Engineer'] },
  software_ai: { id: 'software_ai', label: 'Software & Artificial Intelligence', pathwayIds: ['engineering_intelligent_systems'], examples: ['Software Engineer', 'AI Engineer', 'Machine Learning Engineer'] },
  mechanical_product_engineering: { id: 'mechanical_product_engineering', label: 'Mechanical & Product Engineering', pathwayIds: ['engineering_intelligent_systems'], examples: ['Mechanical Engineer', 'Product Engineer', 'Industrial Designer'] },
  aerospace_space_systems: { id: 'aerospace_space_systems', label: 'Aerospace & Space Systems', pathwayIds: ['engineering_intelligent_systems', 'science_exploration'], examples: ['Aerospace Engineer', 'Space Systems Engineer', 'Mission Scientist'] },
  medicine_clinical_care: { id: 'medicine_clinical_care', label: 'Medicine & Clinical Care', pathwayIds: ['health_human_sciences'], examples: ['Physician', 'Nurse', 'Physician Assistant'] },
  biomedical_health_technology: { id: 'biomedical_health_technology', label: 'Biomedical & Health Technology', pathwayIds: ['health_human_sciences', 'engineering_intelligent_systems'], examples: ['Biomedical Engineer', 'Medical Device Engineer', 'Health Technology Specialist'] },
  scientific_research: { id: 'scientific_research', label: 'Scientific Research', pathwayIds: ['science_exploration'], examples: ['Research Scientist', 'Physicist', 'Chemist'] },
  writing_media_storytelling: { id: 'writing_media_storytelling', label: 'Writing, Media & Storytelling', pathwayIds: ['creative_design_expression'], examples: ['Writer', 'Journalist', 'Content Creator'] },
  design_digital_experiences: { id: 'design_digital_experiences', label: 'Design & Digital Experiences', pathwayIds: ['creative_design_expression'], examples: ['UX Designer', 'Product Designer', 'Game Designer'] },
  environment_sustainability: { id: 'environment_sustainability', label: 'Environment & Sustainability', pathwayIds: ['environment_living_systems'], examples: ['Environmental Scientist', 'Conservation Scientist', 'Sustainability Specialist'] },
  animal_life_sciences: { id: 'animal_life_sciences', label: 'Animal & Life Sciences', pathwayIds: ['environment_living_systems', 'health_human_sciences'], examples: ['Veterinarian', 'Wildlife Biologist', 'Zoologist'] },
  entrepreneurship_product_business: { id: 'entrepreneurship_product_business', label: 'Entrepreneurship, Product & Business', pathwayIds: ['innovation_entrepreneurship'], examples: ['Entrepreneur', 'Product Manager', 'Business Strategist'] },
  leadership_community_service: { id: 'leadership_community_service', label: 'Leadership & Community Service', pathwayIds: ['people_leadership_society'], examples: ['Community Leader', 'Educator', 'Public Service Professional'] },
}

export const confidenceLevels = [
  { id: 'exploratory', label: 'Exploratory', minScore: 0, maxScore: 24 },
  { id: 'emerging', label: 'Emerging', minScore: 25, maxScore: 49 },
  { id: 'developing', label: 'Developing', minScore: 50, maxScore: 74 },
  { id: 'strong', label: 'Strong', minScore: 75, maxScore: 100 },
]

// ============================================================
// MVP v0.6 — EVIDENCE STREAMS
//
// Stream = whose perspective / what kind of observation?
// Source type = what specific interaction created the evidence?
// ============================================================

export const evidenceStreams = {
  KID_EXPERIENCE: 'kid_experience',
  PARENT_OBSERVATION: 'parent_observation',
  SYSTEM_EVIDENCE: 'system_evidence',
}

export const evidenceSourceTypes = {
  DISCOVERY: 'discovery',
  PARENT_OBSERVATION: 'parent_observation',
  ADVENTURE_QUESTION: 'adventure_question',
  ADVENTURE_CHOICE: 'adventure_choice',
  REFLECTION: 'reflection',
  COMPLETION: 'completion',
  COMPANION_OUTCOME: 'companion_outcome',
}

export const evidenceStreamBySourceType = {
  [evidenceSourceTypes.DISCOVERY]:
    evidenceStreams.KID_EXPERIENCE,

  [evidenceSourceTypes.PARENT_OBSERVATION]:
    evidenceStreams.PARENT_OBSERVATION,

  [evidenceSourceTypes.ADVENTURE_QUESTION]:
    evidenceStreams.KID_EXPERIENCE,

  [evidenceSourceTypes.ADVENTURE_CHOICE]:
    evidenceStreams.KID_EXPERIENCE,

  [evidenceSourceTypes.REFLECTION]:
    evidenceStreams.KID_EXPERIENCE,

  [evidenceSourceTypes.COMPLETION]:
    evidenceStreams.SYSTEM_EVIDENCE,

  // v0.16 adaptive learning loop: child responses to delivered guidance.
  // These remain evidence, never direct profile facts.
  [evidenceSourceTypes.COMPANION_OUTCOME]:
    evidenceStreams.KID_EXPERIENCE,
}

export function getEvidenceStreamForSourceType(sourceType) {
  return (
    evidenceStreamBySourceType[sourceType] ||
    evidenceStreams.KID_EXPERIENCE
  )
}

export function isValidSignalId(signalId) {
  return Boolean(signals[signalId])
}

export function isValidTraitId(traitId) {
  return Boolean(traits[traitId])
}

export function isValidDomainId(domainId) {
  return Boolean(domains[domainId])
}

export function isValidPathwayId(pathwayId) {
  return Boolean(pathways[pathwayId])
}

export function isValidCareerFamilyId(careerFamilyId) {
  return Boolean(careerFamilies[careerFamilyId])
}

export function getConfidenceLevel(score = 0) {
  const safeScore = Math.max(
    0,
    Math.min(100, Number(score) || 0)
  )

  return (
    confidenceLevels.find(
      (level) =>
        safeScore >= level.minScore &&
        safeScore <= level.maxScore
    ) || confidenceLevels[0]
  )
}

export function validateGrowthTaxonomy() {
  const errors = []

  Object.values(traits).forEach((trait) => {
    Object.keys(trait.signalWeights || {}).forEach(
      (signalId) => {
        if (!signals[signalId]) {
          errors.push(
            `Trait "${trait.id}" references unknown signal "${signalId}".`
          )
        }
      }
    )
  })

  Object.values(pathways).forEach((pathway) => {
    Object.keys(pathway.traitWeights || {}).forEach(
      (traitId) => {
        if (!traits[traitId]) {
          errors.push(
            `Pathway "${pathway.id}" references unknown trait "${traitId}".`
          )
        }
      }
    )

    Object.keys(pathway.domainWeights || {}).forEach(
      (domainId) => {
        if (!domains[domainId]) {
          errors.push(
            `Pathway "${pathway.id}" references unknown domain "${domainId}".`
          )
        }
      }
    )

    const traitWeightTotal = Object.values(
      pathway.traitWeights || {}
    ).reduce((total, weight) => total + weight, 0)

    const domainWeightTotal = Object.values(
      pathway.domainWeights || {}
    ).reduce((total, weight) => total + weight, 0)

    const totalWeight =
      traitWeightTotal + domainWeightTotal

    if (Math.abs(totalWeight - 1) > 0.0001) {
      errors.push(
        `Pathway "${pathway.id}" weights total ${totalWeight.toFixed(4)} instead of 1.0.`
      )
    }
  })

  Object.values(careerFamilies).forEach(
    (careerFamily) => {
      careerFamily.pathwayIds.forEach((pathwayId) => {
        if (!pathways[pathwayId]) {
          errors.push(
            `Career family "${careerFamily.id}" references unknown pathway "${pathwayId}".`
          )
        }
      })
    }
  )

  return {
    valid: errors.length === 0,
    errors,
  }
}

export const growthTaxonomy = {
  modelVersion: GROWTH_MODEL_VERSION,
  signals,
  traits,
  domains,
  pathways,
  careerFamilies,
  confidenceLevels,
  evidenceStreams,
  evidenceSourceTypes,
  evidenceStreamBySourceType,
}

export default growthTaxonomy
